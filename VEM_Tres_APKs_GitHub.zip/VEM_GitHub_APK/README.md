# VEM — Cliente, Motorista e Operador

Código-fonte Flutter dos três protótipos. Consulte `README_GERAR_APKS.md` para compilar os APKs através do GitHub Actions.

**Estado:** protótipos; não ligados a um backend partilhado e não prontos para operação real.
