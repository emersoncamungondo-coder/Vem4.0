# VEM — gerar os três APKs no GitHub

Este pacote contém três protótipos Flutter e um workflow que compila um APK Android para cada aplicação.

## O que está incluído
- `apps/vem_cliente` — aplicação do passageiro.
- `apps/vem_motorista` — aplicação do motorista.
- `apps/vem_operador` — painel do operador.
- `.github/workflows/build-apks.yml` — compilação automática dos três APKs.

## Como gerar usando apenas o telemóvel
1. Cria ou inicia sessão numa conta GitHub.
2. Cria um repositório novo chamado `VEM-Apps` (pode ser privado).
3. Extrai este ZIP e carrega todos os ficheiros e pastas para a raiz do repositório, mantendo a estrutura `apps/` e `.github/`.
4. Abre o separador **Actions** do repositório.
5. Selecciona **Gerar APKs VEM** e toca em **Run workflow**. Também começa automaticamente quando fizeres push para `main`.
6. Aguarda os três trabalhos terminarem com sucesso.
7. Abre a execução concluída e descarrega os artefactos `vem_cliente-apk`, `vem_motorista-apk` e `vem_operador-apk`.
8. Cada artefacto é um ZIP. Extrai-o e instala o `app-release.apk` no Android.

## Limitações importantes desta versão
- São protótipos de interface e fluxos de demonstração, não uma plataforma de transporte pronta para operar.
- As três apps ainda não partilham backend; não comunicam entre si nem recebem pedidos reais.
- Mapa/GPS reais, autenticação por telefone/SMS, notificações, pagamentos integrados, segurança e sincronização precisam de implementação e testes próprios.
- Não usar para transportar passageiros nem recolher dados reais até concluir essas integrações e testes.
- A compilação depende de o GitHub Actions executar com sucesso; este pacote não contém APKs já compilados.
