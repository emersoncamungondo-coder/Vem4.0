# VEM Operador — protótipo Flutter

Aplicação demonstrativa para a central de operações da VEM.

## Incluído
- Painel com indicadores de viagens e motoristas.
- Lista e pesquisa de viagens.
- Registo manual de viagens.
- Atribuição de motoristas disponíveis, cancelamento e conclusão de viagens.
- Gestão básica de motoristas e estado.
- Relatórios calculados a partir de dados fictícios.
- Mapa ilustrativo sem GPS real.

## Executar
1. Instale o Flutter SDK e Android Studio.
2. Na pasta do projecto, execute `flutter pub get`.
3. Execute `flutter run`.
4. Para gerar APK de teste: `flutter build apk --debug`.

## Importante
Este é um protótipo local, não uma central operacional real. Os dados ficam apenas na memória durante a execução e são fictícios. Não há autenticação, permissões de operador, servidor partilhado, GPS, mapas reais, notificações nem integração com as apps Cliente/Motorista. Antes de publicar, é necessário criar backend seguro, autenticação e controlo de acesso por funções, sincronização em tempo real, auditoria e testes.
