import 'package:flutter/material.dart';

void main() => runApp(const VemOperadorApp());

const navy = Color(0xFF10243A);
const green = Color(0xFF19A974);
const bg = Color(0xFFF3F6F8);

class VemOperadorApp extends StatelessWidget {
  const VemOperadorApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'VEM Operador',
      theme: ThemeData(
        useMaterial3: true,
        scaffoldBackgroundColor: bg,
        colorScheme: ColorScheme.fromSeed(seedColor: green),
        appBarTheme: const AppBarTheme(
          backgroundColor: navy,
          foregroundColor: Colors.white,
          centerTitle: false,
        ),
      ),
      home: const OperatorHome(),
    );
  }
}

class Trip {
  Trip(this.client, this.driver, this.route, this.price, this.status);
  final String client;
  final String driver;
  final String route;
  final int price;
  String status;
}

class OperatorHome extends StatefulWidget {
  const OperatorHome({super.key});

  @override
  State<OperatorHome> createState() => _OperatorHomeState();
}

class _OperatorHomeState extends State<OperatorHome> {
  int tab = 0;
  final search = TextEditingController();
  final trips = <Trip>[
    Trip('Marta Manuel', 'Paulo António', 'Camama → Talatona', 1500, 'Em curso'),
    Trip('José Pedro', 'Sem motorista', 'Cacuaco → São Paulo', 2100, 'À procura'),
    Trip('Ana Domingos', 'Carlos Miguel', 'Maianga → Ingombota', 900, 'Concluída'),
    Trip('Dário Francisco', 'Sem motorista', 'Benfica → Patriota', 1200, 'À procura'),
  ];
  final drivers = <Map<String, String>>[
    {'name': 'Paulo António', 'car': 'Toyota Corolla', 'plate': 'LD-24-35-AB', 'state': 'Em viagem'},
    {'name': 'Carlos Miguel', 'car': 'Hyundai i10', 'plate': 'LD-67-18-CD', 'state': 'Disponível'},
    {'name': 'Mateus João', 'car': 'Kia Picanto', 'plate': 'LD-90-41-EF', 'state': 'Offline'},
  ];

  int get activeTrips => trips.where((t) => t.status == 'Em curso' || t.status == 'À procura').length;
  int get waitingTrips => trips.where((t) => t.status == 'À procura').length;
  int get onlineDrivers => drivers.where((d) => d['state'] != 'Offline').length;

  @override
  void dispose() {
    search.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final titles = ['Painel do operador', 'Viagens', 'Motoristas', 'Relatórios'];
    return Scaffold(
      appBar: AppBar(
        title: Row(children: [
          Container(
            width: 38, height: 38,
            decoration: BoxDecoration(color: green, borderRadius: BorderRadius.circular(12)),
            child: const Icon(Icons.local_taxi, color: Colors.white),
          ),
          const SizedBox(width: 10),
          Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text(titles[tab], style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w800)),
            const Text('VEM • Central de operações', style: TextStyle(fontSize: 11, color: Colors.white70)),
          ]),
        ]),
      ),
      drawer: _drawer(),
      body: SafeArea(
        child: IndexedStack(
          index: tab,
          children: [
            _dashboard(),
            _tripsPage(),
            _driversPage(),
            _reportsPage(),
          ],
        ),
      ),
      bottomNavigationBar: NavigationBar(
        selectedIndex: tab,
        onDestinationSelected: (i) => setState(() => tab = i),
        destinations: const [
          NavigationDestination(icon: Icon(Icons.dashboard_outlined), selectedIcon: Icon(Icons.dashboard), label: 'Painel'),
          NavigationDestination(icon: Icon(Icons.route_outlined), selectedIcon: Icon(Icons.route), label: 'Viagens'),
          NavigationDestination(icon: Icon(Icons.people_outline), selectedIcon: Icon(Icons.people), label: 'Motoristas'),
          NavigationDestination(icon: Icon(Icons.bar_chart_outlined), selectedIcon: Icon(Icons.bar_chart), label: 'Relatórios'),
        ],
      ),
    );
  }

  Widget _drawer() => Drawer(
    child: Column(children: [
      Container(
        width: double.infinity, padding: const EdgeInsets.fromLTRB(22, 48, 22, 22),
        color: navy,
        child: const Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          CircleAvatar(radius: 28, backgroundColor: green, child: Icon(Icons.admin_panel_settings, color: Colors.white, size: 30)),
          SizedBox(height: 12),
          Text('VEM Operador', style: TextStyle(color: Colors.white, fontSize: 20, fontWeight: FontWeight.bold)),
          Text('Área de gestão • Demonstração', style: TextStyle(color: Colors.white70)),
        ]),
      ),
      _drawerItem(Icons.dashboard, 'Painel', 0),
      _drawerItem(Icons.route, 'Viagens', 1),
      _drawerItem(Icons.people, 'Motoristas', 2),
      _drawerItem(Icons.bar_chart, 'Relatórios', 3),
      const Spacer(),
      const Padding(padding: EdgeInsets.all(16), child: Text('Protótipo local — dados fictícios', style: TextStyle(color: Colors.black54, fontSize: 12))),
    ]),
  );

  Widget _drawerItem(IconData icon, String label, int index) => ListTile(
    leading: Icon(icon), title: Text(label), selected: tab == index,
    onTap: () { setState(() => tab = index); Navigator.pop(context); },
  );

  Widget _dashboard() => ListView(
    padding: const EdgeInsets.all(16),
    children: [
      const Text('Bom dia, Operador 👋', style: TextStyle(fontSize: 23, fontWeight: FontWeight.w800, color: navy)),
      const SizedBox(height: 5),
      const Text('Resumo da actividade da plataforma', style: TextStyle(color: Colors.black54)),
      const SizedBox(height: 18),
      GridView.count(
        crossAxisCount: 2, shrinkWrap: true, physics: const NeverScrollableScrollPhysics(),
        crossAxisSpacing: 12, mainAxisSpacing: 12, childAspectRatio: 1.42,
        children: [
          _statCard('Viagens activas', '$activeTrips', Icons.route, const Color(0xFFE6F6EF)),
          _statCard('À procura', '$waitingTrips', Icons.person_search, const Color(0xFFFFF1D6)),
          _statCard('Motoristas online', '$onlineDrivers', Icons.local_taxi, const Color(0xFFE5EEFF)),
          _statCard('Concluídas', '${trips.where((t) => t.status == 'Concluída').length}', Icons.check_circle_outline, const Color(0xFFEDE7F6)),
        ],
      ),
      const SizedBox(height: 20),
      _sectionHeader('Mapa operacional', 'Ilustração'),
      const SizedBox(height: 10),
      const _MapPanel(),
      const SizedBox(height: 20),
      _sectionHeader('Viagens recentes', 'Ver todas', onTap: () => setState(() => tab = 1)),
      const SizedBox(height: 8),
      ...trips.take(3).map(_tripTile),
      const SizedBox(height: 12),
      FilledButton.icon(
        onPressed: () => _newTripDialog(),
        icon: const Icon(Icons.add),
        label: const Text('Registar viagem manualmente'),
        style: FilledButton.styleFrom(backgroundColor: green, padding: const EdgeInsets.symmetric(vertical: 14)),
      ),
    ],
  );

  Widget _statCard(String label, String value, IconData icon, Color color) => Container(
    padding: const EdgeInsets.all(15),
    decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(18), boxShadow: const [BoxShadow(color: Color(0x08000000), blurRadius: 10, offset: Offset(0, 3))]),
    child: Column(crossAxisAlignment: CrossAxisAlignment.start, mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
      Container(padding: const EdgeInsets.all(8), decoration: BoxDecoration(color: color, borderRadius: BorderRadius.circular(12)), child: Icon(icon, color: navy, size: 20)),
      Text(value, style: const TextStyle(fontSize: 27, fontWeight: FontWeight.w800, color: navy)),
      Text(label, style: const TextStyle(fontSize: 12, color: Colors.black54)),
    ]),
  );

  Widget _sectionHeader(String title, String action, {VoidCallback? onTap}) => Row(
    mainAxisAlignment: MainAxisAlignment.spaceBetween,
    children: [
      Text(title, style: const TextStyle(fontSize: 17, fontWeight: FontWeight.w800, color: navy)),
      TextButton(onPressed: onTap ?? () {}, child: Text(action)),
    ],
  );

  Widget _tripsPage() => ListView(
    padding: const EdgeInsets.all(16),
    children: [
      const Text('Gestão de viagens', style: TextStyle(fontSize: 22, fontWeight: FontWeight.w800, color: navy)),
      const SizedBox(height: 12),
      TextField(
        controller: search,
        onChanged: (_) => setState(() {}),
        decoration: InputDecoration(
          hintText: 'Pesquisar cliente, motorista ou rota',
          prefixIcon: const Icon(Icons.search),
          filled: true, fillColor: Colors.white,
          border: OutlineInputBorder(borderRadius: BorderRadius.circular(14), borderSide: BorderSide.none),
        ),
      ),
      const SizedBox(height: 12),
      ...trips.where((t) => '${t.client} ${t.driver} ${t.route} ${t.status}'.toLowerCase().contains(search.text.toLowerCase())).map(_tripTile),
      const SizedBox(height: 12),
      OutlinedButton.icon(onPressed: _newTripDialog, icon: const Icon(Icons.add), label: const Text('Nova viagem')),
    ],
  );

  Widget _tripTile(Trip t) {
    Color statusColor = t.status == 'Concluída' ? green : (t.status == 'À procura' ? Colors.orange.shade800 : Colors.blue.shade700);
    return Container(
      margin: const EdgeInsets.only(bottom: 10),
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(16)),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Row(children: [
          Expanded(child: Text(t.route, style: const TextStyle(fontWeight: FontWeight.w800, color: navy))),
          Container(padding: const EdgeInsets.symmetric(horizontal: 9, vertical: 5), decoration: BoxDecoration(color: statusColor.withOpacity(.12), borderRadius: BorderRadius.circular(20)), child: Text(t.status, style: TextStyle(color: statusColor, fontSize: 11, fontWeight: FontWeight.w700))),
        ]),
        const SizedBox(height: 8),
        Text('Cliente: ${t.client}', style: const TextStyle(color: Colors.black87)),
        Text('Motorista: ${t.driver}', style: const TextStyle(color: Colors.black54)),
        const SizedBox(height: 8),
        Row(children: [
          Text('${t.price} Kz', style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 16)),
          const Spacer(),
          if (t.status == 'À procura') ...[
            TextButton(onPressed: () => _assignDriver(t), child: const Text('Atribuir')),
            IconButton(onPressed: () => _cancelTrip(t), icon: const Icon(Icons.close, color: Colors.red), tooltip: 'Cancelar'),
          ] else if (t.status == 'Em curso')
            TextButton(onPressed: () => _finishTrip(t), child: const Text('Concluir')),
        ]),
      ]),
    );
  }

  Widget _driversPage() => ListView(
    padding: const EdgeInsets.all(16),
    children: [
      Row(children: [
        const Expanded(child: Text('Motoristas', style: TextStyle(fontSize: 22, fontWeight: FontWeight.w800, color: navy))),
        FilledButton.icon(onPressed: _addDriverDialog, icon: const Icon(Icons.person_add_alt_1), label: const Text('Adicionar')),
      ]),
      const SizedBox(height: 8),
      Text('$onlineDrivers motoristas com actividade registada', style: const TextStyle(color: Colors.black54)),
      const SizedBox(height: 12),
      ...drivers.map((d) {
        final state = d['state']!;
        final color = state == 'Disponível' ? green : state == 'Em viagem' ? Colors.blue : Colors.grey;
        return Container(
          margin: const EdgeInsets.only(bottom: 10), padding: const EdgeInsets.all(14),
          decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(16)),
          child: Row(children: [
            CircleAvatar(backgroundColor: const Color(0xFFE6F6EF), child: Icon(Icons.person, color: navy)),
            const SizedBox(width: 12),
            Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text(d['name']!, style: const TextStyle(fontWeight: FontWeight.w800)),
              Text('${d['car']} • ${d['plate']}', style: const TextStyle(fontSize: 12, color: Colors.black54)),
              const SizedBox(height: 5),
              Text(state, style: TextStyle(color: color, fontWeight: FontWeight.w700, fontSize: 12)),
            ])),
            PopupMenuButton<String>(
              onSelected: (v) => setState(() => d['state'] = v),
              itemBuilder: (_) => const [
                PopupMenuItem(value: 'Disponível', child: Text('Marcar disponível')),
                PopupMenuItem(value: 'Em viagem', child: Text('Marcar em viagem')),
                PopupMenuItem(value: 'Offline', child: Text('Marcar offline')),
              ],
            ),
          ]),
        );
      }),
    ],
  );

  Widget _reportsPage() {
    final completed = trips.where((t) => t.status == 'Concluída').toList();
    final total = completed.fold<int>(0, (sum, t) => sum + t.price);
    return ListView(padding: const EdgeInsets.all(16), children: [
      const Text('Relatórios', style: TextStyle(fontSize: 22, fontWeight: FontWeight.w800, color: navy)),
      const SizedBox(height: 6),
      const Text('Indicadores calculados a partir dos dados de demonstração.', style: TextStyle(color: Colors.black54)),
      const SizedBox(height: 18),
      _reportCard('Receita das viagens concluídas', '$total Kz', Icons.payments_outlined),
      _reportCard('Total de viagens registadas', '${trips.length}', Icons.route_outlined),
      _reportCard('Taxa de conclusão', trips.isEmpty ? '0%' : '${(completed.length * 100 / trips.length).round()}%', Icons.check_circle_outline),
      const SizedBox(height: 18),
      const Text('Estado das viagens', style: TextStyle(fontSize: 17, fontWeight: FontWeight.w800)),
      const SizedBox(height: 8),
      ...['À procura', 'Em curso', 'Concluída', 'Cancelada'].map((s) {
        final count = trips.where((t) => t.status == s).length;
        return ListTile(
          contentPadding: EdgeInsets.zero,
          title: Text(s),
          trailing: Text('$count', style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 16)),
          subtitle: LinearProgressIndicator(value: trips.isEmpty ? 0 : count / trips.length, color: green, backgroundColor: Colors.black12),
        );
      }),
    ]);
  }

  Widget _reportCard(String title, String value, IconData icon) => Container(
    margin: const EdgeInsets.only(bottom: 12), padding: const EdgeInsets.all(18),
    decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(16)),
    child: Row(children: [
      Container(padding: const EdgeInsets.all(12), decoration: BoxDecoration(color: const Color(0xFFE6F6EF), borderRadius: BorderRadius.circular(12)), child: Icon(icon, color: navy)),
      const SizedBox(width: 12),
      Expanded(child: Text(title, style: const TextStyle(color: Colors.black54))),
      Text(value, style: const TextStyle(fontSize: 19, fontWeight: FontWeight.w800, color: navy)),
    ]),
  );

  void _newTripDialog() {
    final client = TextEditingController();
    final route = TextEditingController();
    final price = TextEditingController(text: '1200');
    showDialog(context: context, builder: (ctx) => AlertDialog(
      title: const Text('Registar viagem'),
      content: SingleChildScrollView(child: Column(mainAxisSize: MainAxisSize.min, children: [
        TextField(controller: client, decoration: const InputDecoration(labelText: 'Nome do cliente')),
        TextField(controller: route, decoration: const InputDecoration(labelText: 'Origem → destino')),
        TextField(controller: price, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'Preço (Kz)')),
      ])),
      actions: [
        TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('Cancelar')),
        FilledButton(onPressed: () {
          if (client.text.trim().isEmpty || route.text.trim().isEmpty) return;
          setState(() => trips.insert(0, Trip(client.text.trim(), 'Sem motorista', route.text.trim(), int.tryParse(price.text) ?? 0, 'À procura')));
          Navigator.pop(ctx);
        }, child: const Text('Guardar')),
      ],
    ));
  }

  void _assignDriver(Trip trip) {
    final available = drivers.where((d) => d['state'] == 'Disponível').toList();
    if (available.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Não há motoristas disponíveis neste protótipo.')));
      return;
    }
    showDialog(context: context, builder: (ctx) => AlertDialog(
      title: const Text('Atribuir motorista'),
      content: Column(mainAxisSize: MainAxisSize.min, children: available.map((d) => ListTile(
        leading: const Icon(Icons.local_taxi),
        title: Text(d['name']!),
        subtitle: Text('${d['car']} • ${d['plate']}'),
        onTap: () {
          setState(() { trip.driver = d['name']!; trip.status = 'Em curso'; d['state'] = 'Em viagem'; });
          Navigator.pop(ctx);
        },
      )).toList()),
    ));
  }

  void _cancelTrip(Trip trip) {
    setState(() => trip.status = 'Cancelada');
    ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Viagem cancelada na demonstração.')));
  }

  void _finishTrip(Trip trip) {
    setState(() {
      trip.status = 'Concluída';
      final driver = drivers.where((d) => d['name'] == trip.driver).firstOrNull;
      if (driver != null) driver['state'] = 'Disponível';
    });
  }

  void _addDriverDialog() {
    final name = TextEditingController();
    final car = TextEditingController();
    final plate = TextEditingController();
    showDialog(context: context, builder: (ctx) => AlertDialog(
      title: const Text('Adicionar motorista'),
      content: SingleChildScrollView(child: Column(mainAxisSize: MainAxisSize.min, children: [
        TextField(controller: name, decoration: const InputDecoration(labelText: 'Nome completo')),
        TextField(controller: car, decoration: const InputDecoration(labelText: 'Modelo do carro')),
        TextField(controller: plate, decoration: const InputDecoration(labelText: 'Matrícula')),
      ])),
      actions: [
        TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('Cancelar')),
        FilledButton(onPressed: () {
          if (name.text.trim().isEmpty || car.text.trim().isEmpty || plate.text.trim().isEmpty) return;
          setState(() => drivers.add({'name': name.text.trim(), 'car': car.text.trim(), 'plate': plate.text.trim(), 'state': 'Offline'}));
          Navigator.pop(ctx);
        }, child: const Text('Adicionar')),
      ],
    ));
  }
}

class _MapPanel extends StatelessWidget {
  const _MapPanel();

  @override
  Widget build(BuildContext context) => Container(
    height: 190, clipBehavior: Clip.antiAlias,
    decoration: BoxDecoration(color: const Color(0xFFE2ECE8), borderRadius: BorderRadius.circular(18)),
    child: Stack(children: [
      Positioned.fill(child: CustomPaint(painter: _RoadPainter())),
      const Positioned(left: 35, top: 36, child: _MapPin(label: 'Camama', color: green)),
      const Positioned(right: 30, top: 82, child: _MapPin(label: 'Talatona', color: Colors.blue)),
      const Positioned(left: 130, bottom: 24, child: _MapPin(label: 'Cacuaco', color: Colors.orange)),
      Positioned(left: 12, bottom: 10, child: Container(padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 5), decoration: BoxDecoration(color: Colors.white.withOpacity(.88), borderRadius: BorderRadius.circular(8)), child: const Text('Mapa ilustrativo • sem GPS', style: TextStyle(fontSize: 10, color: navy))),
    ]),
  );
}

class _MapPin extends StatelessWidget {
  const _MapPin({required this.label, required this.color});
  final String label;
  final Color color;
  @override
  Widget build(BuildContext context) => Column(mainAxisSize: MainAxisSize.min, children: [
    Icon(Icons.location_on, color: color, size: 31),
    Container(padding: const EdgeInsets.symmetric(horizontal: 7, vertical: 3), decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(7)), child: Text(label, style: const TextStyle(fontSize: 10, fontWeight: FontWeight.w700))),
  ]);
}

class _RoadPainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    final road = Paint()..color = Colors.white..strokeWidth = 13..style = PaintingStyle.stroke..strokeCap = StrokeCap.round;
    final thin = Paint()..color = const Color(0xFFCADAD3)..strokeWidth = 2..style = PaintingStyle.stroke;
    final p = Path()
      ..moveTo(-10, size.height * .22)..cubicTo(size.width * .25, size.height * .12, size.width * .45, size.height * .48, size.width + 10, size.height * .32);
    canvas.drawPath(p, road);
    final p2 = Path()
      ..moveTo(size.width * .25, -10)..cubicTo(size.width * .35, size.height * .25, size.width * .1, size.height * .6, size.width * .38, size.height + 10);
    canvas.drawPath(p2, road);
    final p3 = Path()
      ..moveTo(-10, size.height * .82)..cubicTo(size.width * .3, size.height * .65, size.width * .65, size.height * .9, size.width + 10, size.height * .68);
    canvas.drawPath(p3, road);
    for (int i = 0; i < 7; i++) {
      canvas.drawLine(Offset(0, i * 34.0), Offset(size.width, i * 34.0 + 15), thin);
    }
  }
  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}
