# VEM Motorista — protótipo Flutter

Primeira versão da aplicação do motorista VEM. Contém ecrãs e fluxos de demonstração, sem ligação a pedidos reais, servidor, GPS ou mapas de navegação.

## Requisitos
- Flutter SDK instalado
- Android Studio ou VS Code com extensões Flutter/Dart
- Android SDK para executar num telemóvel/emulador

## Executar
1. Extrai o ZIP.
2. Abre a pasta `vem_motorista` no Android Studio ou VS Code.
3. No terminal, executa:
   ```bash
   flutter pub get
   flutter run
   ```

Para criar APK de teste:
```bash
flutter build apk --debug
```
O APK costuma ficar em `build/app/outputs/flutter-apk/app-debug.apk`.

## Incluído
- Estado online/offline.
- Pedido de viagem fictício com aceitar/recusar.
- Viagem em andamento com acção para terminar.
- Confirmação de pagamento recebido.
- Resumo e histórico local de ganhos de demonstração.
- Perfil com dados editáveis da viatura e motorista.
- Mapa ilustrativo, sem GPS ou navegação reais.

## Antes de produção
- Autenticação e validação documental do motorista.
- Backend partilhado com Cliente e Operador.
- Distribuição de pedidos em tempo real.
- GPS em segundo plano, permissões e integração de mapas/rotas.
- Tarifas oficiais, comissões, recibos, suporte e avaliações.
- Segurança, privacidade, testes em dispositivos e publicação.

Todos os pedidos, endereços e valores são fictícios, servem apenas para testar a interface e não devem ser usados como registos de viagens reais.
