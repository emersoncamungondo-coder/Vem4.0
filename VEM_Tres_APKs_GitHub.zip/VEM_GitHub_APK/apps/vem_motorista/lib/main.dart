import 'package:flutter/material.dart';

void main() => runApp(const VemMotoristaApp());

const vemGreen = Color(0xFF087F5B);
const vemDark = Color(0xFF10231D);
const vemMuted = Color(0xFF718078);
const vemBg = Color(0xFFF5F7F6);
const vemOrange = Color(0xFFF0A33A);

class VemMotoristaApp extends StatelessWidget {
  const VemMotoristaApp({super.key});

  @override
  Widget build(BuildContext context) => MaterialApp(
    title: 'VEM Motorista',
    debugShowCheckedModeBanner: false,
    theme: ThemeData(
      useMaterial3: true,
      scaffoldBackgroundColor: vemBg,
      colorScheme: ColorScheme.fromSeed(seedColor: vemGreen),
      inputDecorationTheme: InputDecorationTheme(
        filled: true,
        fillColor: Colors.white,
        contentPadding: const EdgeInsets.symmetric(horizontal: 14, vertical: 15),
        border: OutlineInputBorder(borderRadius: BorderRadius.circular(14), borderSide: BorderSide.none),
      ),
    ),
    home: const DriverHome(),
  );
}

class DriverHome extends StatefulWidget {
  const DriverHome({super.key});
  @override
  State<DriverHome> createState() => _DriverHomeState();
}

class _DriverHomeState extends State<DriverHome> {
  int _tab = 0;
  bool _online = false;
  bool _hasRequest = false;
  bool _tripActive = false;
  bool _tripFinished = false;
  bool _paymentConfirmed = false;
  bool _available = true;
  final List<_TripRecord> _history = [];
  final _nameController = TextEditingController(text: 'Motorista VEM');
  final _plateController = TextEditingController(text: 'LD-00-00-AA');
  final _carController = TextEditingController(text: 'Toyota Corolla');
  final _phoneController = TextEditingController();

  @override
  void dispose() {
    _nameController.dispose();
    _plateController.dispose();
    _carController.dispose();
    _phoneController.dispose();
    super.dispose();
  }

  void _showMessage(String message) {
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(message)));
  }

  void _toggleOnline(bool value) {
    setState(() => _online = value);
    _showMessage(value
      ? 'Ficaste online no modo de demonstração. Não receberás pedidos reais.'
      : 'Ficaste offline.');
  }

  void _acceptRequest() {
    setState(() {
      _hasRequest = false;
      _tripActive = true;
      _tripFinished = false;
      _paymentConfirmed = false;
    });
  }

  void _finishTrip() {
    setState(() {
      _tripActive = false;
      _tripFinished = true;
    });
  }

  void _confirmPayment() {
    setState(() {
      _paymentConfirmed = true;
      _tripFinished = false;
      _history.insert(0, _TripRecord(
        destination: 'Talatona, Luanda',
        price: 900,
        date: DateTime.now(),
      ));
    });
    _showMessage('Pagamento registado localmente (demonstração).');
  }

  @override
  Widget build(BuildContext context) {
    final pages = [_dashboard(), _earningsPage(), _profilePage()];
    return Scaffold(
      body: SafeArea(child: IndexedStack(index: _tab, children: pages)),
      bottomNavigationBar: NavigationBar(
        selectedIndex: _tab,
        onDestinationSelected: (i) => setState(() => _tab = i),
        backgroundColor: Colors.white,
        indicatorColor: vemGreen.withOpacity(.12),
        destinations: const [
          NavigationDestination(icon: Icon(Icons.dashboard_outlined), selectedIcon: Icon(Icons.dashboard), label: 'Painel'),
          NavigationDestination(icon: Icon(Icons.account_balance_wallet_outlined), selectedIcon: Icon(Icons.account_balance_wallet), label: 'Ganhos'),
          NavigationDestination(icon: Icon(Icons.person_outline), selectedIcon: Icon(Icons.person), label: 'Perfil'),
        ],
      ),
    );
  }

  Widget _dashboard() {
    return ListView(
      padding: const EdgeInsets.fromLTRB(18, 14, 18, 24),
      children: [
        Row(children: [
          Container(
            width: 46, height: 46,
            decoration: BoxDecoration(color: vemGreen, borderRadius: BorderRadius.circular(15)),
            child: const Icon(Icons.local_taxi_rounded, color: Colors.white, size: 27),
          ),
          const SizedBox(width: 12),
          const Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text('VEM MOTORISTA', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w900, letterSpacing: .7, color: vemDark)),
            Text('O teu trabalho, a tua estrada.', style: TextStyle(color: vemMuted, fontSize: 12)),
          ])),
          const Icon(Icons.notifications_none_rounded, size: 27),
        ]),
        const SizedBox(height: 20),
        Container(
          padding: const EdgeInsets.all(18),
          decoration: BoxDecoration(
            gradient: const LinearGradient(colors: [vemGreen, Color(0xFF075C43)], begin: Alignment.topLeft, end: Alignment.bottomRight),
            borderRadius: BorderRadius.circular(22),
          ),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            const Text('Estado da actividade', style: TextStyle(color: Colors.white70)),
            const SizedBox(height: 5),
            Text(_online ? 'Estás ONLINE' : 'Estás OFFLINE', style: const TextStyle(color: Colors.white, fontSize: 25, fontWeight: FontWeight.w900)),
            const SizedBox(height: 5),
            Text(_online ? 'No modo de demonstração, podes simular um pedido.' : 'Fica online para começares a receber pedidos quando o servidor estiver ligado.', style: const TextStyle(color: Colors.white, height: 1.4)),
            const SizedBox(height: 14),
            Row(children: [
              Expanded(child: Text(_online ? 'Disponível para pedidos' : 'Sem pedidos activos', style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w600))),
              Switch(value: _online, onChanged: _toggleOnline, activeColor: Colors.white, activeTrackColor: const Color(0xFF64CBA8)),
            ]),
          ]),
        ),
        const SizedBox(height: 16),
        Row(children: [
          Expanded(child: _statCard('Ganhos hoje', '${_todayEarnings} Kz', Icons.payments_outlined)),
          const SizedBox(width: 12),
          Expanded(child: _statCard('Viagens', '${_history.length}', Icons.route_outlined)),
        ]),
        const SizedBox(height: 20),
        const Text('Gestão de viagem', style: TextStyle(fontSize: 19, fontWeight: FontWeight.w800, color: vemDark)),
        const SizedBox(height: 10),
        if (_tripActive) _activeTripCard()
        else if (_tripFinished) _paymentCard()
        else if (_hasRequest) _requestCard()
        else _waitingCard(),
        const SizedBox(height: 16),
        if (_online && !_hasRequest && !_tripActive && !_tripFinished)
          OutlinedButton.icon(
            onPressed: () => setState(() => _hasRequest = true),
            icon: const Icon(Icons.notifications_active_outlined),
            label: const Text('Simular novo pedido de viagem'),
            style: OutlinedButton.styleFrom(foregroundColor: vemGreen, padding: const EdgeInsets.all(15), side: const BorderSide(color: vemGreen)),
          ),
        const SizedBox(height: 8),
        const Text('Protótipo de demonstração: pedidos, localização e ganhos não são reais.', textAlign: TextAlign.center, style: TextStyle(fontSize: 11, color: vemMuted)),
      ],
    );
  }

  int get _todayEarnings => _history.fold(0, (sum, trip) => sum + trip.price);

  Widget _statCard(String title, String value, IconData icon) => Container(
    padding: const EdgeInsets.all(15),
    decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(18)),
    child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      Icon(icon, color: vemGreen, size: 23),
      const SizedBox(height: 12),
      Text(value, style: const TextStyle(fontSize: 21, fontWeight: FontWeight.w900, color: vemDark)),
      const SizedBox(height: 3),
      Text(title, style: const TextStyle(fontSize: 12, color: vemMuted)),
    ]),
  );

  Widget _waitingCard() => Container(
    padding: const EdgeInsets.all(18),
    decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(20)),
    child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      const Row(children: [
        Icon(Icons.hourglass_empty_rounded, color: vemOrange, size: 27),
        SizedBox(width: 10),
        Expanded(child: Text('À espera de viagens', style: TextStyle(fontSize: 17, fontWeight: FontWeight.w800))),
      ]),
      const SizedBox(height: 9),
      Text(_online ? 'Podes simular um pedido usando o botão abaixo.' : 'Activa o estado online para testar o fluxo de pedidos.', style: const TextStyle(color: vemMuted, height: 1.4)),
    ]),
  );

  Widget _requestCard() => Container(
    padding: const EdgeInsets.all(18),
    decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(20), border: Border.all(color: vemGreen.withOpacity(.25))),
    child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      const Row(children: [
        Icon(Icons.notifications_active, color: vemGreen),
        SizedBox(width: 8),
        Text('Novo pedido (simulado)', style: TextStyle(fontSize: 17, fontWeight: FontWeight.w800)),
      ]),
      const SizedBox(height: 15),
      _routeLine(Icons.my_location, 'Partida', 'Maianga, Luanda'),
      _routeLine(Icons.location_on, 'Destino', 'Talatona, Luanda'),
      const Divider(height: 24),
      const Row(children: [
        Expanded(child: Text('Preço estimado', style: TextStyle(color: vemMuted))),
        Text('900 Kz', style: TextStyle(fontSize: 21, fontWeight: FontWeight.w900)),
      ]),
      const SizedBox(height: 14),
      Row(children: [
        Expanded(child: OutlinedButton(onPressed: () => setState(() => _hasRequest = false), child: const Text('Recusar'))),
        const SizedBox(width: 10),
        Expanded(child: FilledButton(onPressed: _acceptRequest, style: FilledButton.styleFrom(backgroundColor: vemGreen, foregroundColor: Colors.white), child: const Text('Aceitar'))),
      ]),
    ]),
  );

  Widget _activeTripCard() => Container(
    padding: const EdgeInsets.all(18),
    decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(20)),
    child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      const Row(children: [
        Icon(Icons.navigation_rounded, color: vemGreen),
        SizedBox(width: 8),
        Text('Viagem em andamento', style: TextStyle(fontSize: 17, fontWeight: FontWeight.w800)),
      ]),
      const SizedBox(height: 15),
      _routeLine(Icons.my_location, 'Partida', 'Maianga, Luanda'),
      _routeLine(Icons.location_on, 'Destino', 'Talatona, Luanda'),
      const SizedBox(height: 12),
      Container(
        height: 115, width: double.infinity,
        decoration: BoxDecoration(color: const Color(0xFFEAF0EC), borderRadius: BorderRadius.circular(15)),
        child: const Center(child: Column(mainAxisSize: MainAxisSize.min, children: [
          Icon(Icons.map_outlined, color: vemGreen, size: 35),
          SizedBox(height: 5),
          Text('Mapa ilustrativo — sem navegação real', style: TextStyle(color: vemMuted, fontSize: 12)),
        ])),
      ),
      const SizedBox(height: 14),
      SizedBox(width: double.infinity, child: FilledButton.icon(
        onPressed: _finishTrip,
        icon: const Icon(Icons.flag_outlined),
        label: const Text('Terminar viagem'),
        style: FilledButton.styleFrom(backgroundColor: vemGreen, foregroundColor: Colors.white, padding: const EdgeInsets.all(15)),
      )),
    ]),
  );

  Widget _paymentCard() => Container(
    padding: const EdgeInsets.all(18),
    decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(20)),
    child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      const Row(children: [
        Icon(Icons.payments_outlined, color: vemGreen),
        SizedBox(width: 8),
        Text('Confirmar pagamento', style: TextStyle(fontSize: 17, fontWeight: FontWeight.w800)),
      ]),
      const SizedBox(height: 10),
      const Text('Destino: Talatona, Luanda', style: TextStyle(color: vemMuted)),
      const SizedBox(height: 4),
      const Text('Total a receber: 900 Kz', style: TextStyle(fontSize: 22, fontWeight: FontWeight.w900)),
      const SizedBox(height: 12),
      SizedBox(width: double.infinity, child: FilledButton.icon(
        onPressed: _confirmPayment,
        icon: const Icon(Icons.check_circle_outline),
        label: const Text('Confirmar pagamento recebido'),
        style: FilledButton.styleFrom(backgroundColor: vemGreen, foregroundColor: Colors.white, padding: const EdgeInsets.all(14)),
      )),
    ]),
  );

  Widget _routeLine(IconData icon, String label, String value) => Padding(
    padding: const EdgeInsets.symmetric(vertical: 6),
    child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
      Icon(icon, size: 20, color: vemGreen),
      const SizedBox(width: 10),
      Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Text(label, style: const TextStyle(fontSize: 11, color: vemMuted)),
        Text(value, style: const TextStyle(fontWeight: FontWeight.w700)),
      ])),
    ]),
  );

  Widget _earningsPage() => ListView(
    padding: const EdgeInsets.all(22),
    children: [
      const SizedBox(height: 18),
      const Text('Os meus ganhos', style: TextStyle(fontSize: 27, fontWeight: FontWeight.w800, color: vemDark)),
      const SizedBox(height: 8),
      const Text('Resumo local das viagens de demonstração.', style: TextStyle(color: vemMuted)),
      const SizedBox(height: 20),
      Container(
        padding: const EdgeInsets.all(22),
        decoration: BoxDecoration(color: vemGreen, borderRadius: BorderRadius.circular(22)),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          const Text('Total registado', style: TextStyle(color: Colors.white70)),
          const SizedBox(height: 7),
          Text('${_todayEarnings} Kz', style: const TextStyle(color: Colors.white, fontSize: 31, fontWeight: FontWeight.w900)),
          const SizedBox(height: 5),
          Text('${_history.length} viagem(ns) concluída(s)', style: const TextStyle(color: Colors.white)),
        ]),
      ),
      const SizedBox(height: 22),
      const Text('Actividade recente', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w800)),
      const SizedBox(height: 10),
      if (_history.isEmpty)
        Container(
          padding: const EdgeInsets.all(25),
          decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(18)),
          child: const Column(children: [
            Icon(Icons.receipt_long_outlined, size: 42, color: vemGreen),
            SizedBox(height: 10),
            Text('Ainda sem registos', style: TextStyle(fontWeight: FontWeight.w700)),
            Text('As viagens concluídas aparecerão aqui.', style: TextStyle(color: vemMuted)),
          ]),
        )
      else
        ..._history.map((trip) => Card(
          elevation: 0, color: Colors.white,
          child: ListTile(
            leading: const CircleAvatar(backgroundColor: Color(0xFFE1F2EA), child: Icon(Icons.local_taxi, color: vemGreen)),
            title: Text(trip.destination, style: const TextStyle(fontWeight: FontWeight.w700)),
            subtitle: Text('${trip.date.day.toString().padLeft(2, '0')}/${trip.date.month.toString().padLeft(2, '0')}/${trip.date.year} • demonstração'),
            trailing: Text('${trip.price} Kz', style: const TextStyle(fontWeight: FontWeight.w800)),
          ),
        )),
    ],
  );

  Widget _profilePage() => ListView(
    padding: const EdgeInsets.all(22),
    children: [
      const SizedBox(height: 18),
      const Text('Perfil do motorista', style: TextStyle(fontSize: 27, fontWeight: FontWeight.w800, color: vemDark)),
      const SizedBox(height: 18),
      Container(
        padding: const EdgeInsets.all(18),
        decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(20)),
        child: Row(children: [
          const CircleAvatar(radius: 28, backgroundColor: Color(0xFFE1F2EA), child: Icon(Icons.person, color: vemGreen, size: 30)),
          const SizedBox(width: 14),
          Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text(_nameController.text.isEmpty ? 'Motorista VEM' : _nameController.text, style: const TextStyle(fontSize: 17, fontWeight: FontWeight.w800)),
            const Text('Perfil de demonstração', style: TextStyle(color: vemMuted)),
          ])),
          IconButton(onPressed: _editProfile, icon: const Icon(Icons.edit_outlined, color: vemGreen)),
        ]),
      ),
      const SizedBox(height: 16),
      _vehicleInfo(Icons.directions_car_outlined, 'Viatura', _carController.text),
      _vehicleInfo(Icons.confirmation_number_outlined, 'Matrícula', _plateController.text),
      _vehicleInfo(Icons.verified_user_outlined, 'Documentos', 'Validação ainda não configurada'),
      _vehicleInfo(Icons.support_agent_outlined, 'Ajuda e suporte', 'Contactar o operador'),
      const SizedBox(height: 16),
      const Text('VEM Motorista • Protótipo 1.0', textAlign: TextAlign.center, style: TextStyle(color: vemMuted, fontSize: 12)),
    ],
  );

  Widget _vehicleInfo(IconData icon, String title, String subtitle) => Card(
    elevation: 0,
    color: Colors.white,
    child: ListTile(
      leading: Icon(icon, color: vemGreen),
      title: Text(title, style: const TextStyle(fontWeight: FontWeight.w700)),
      subtitle: Text(subtitle),
      trailing: const Icon(Icons.chevron_right),
      onTap: title == 'Ajuda e suporte'
        ? () => _showMessage('O suporte será ligado ao operador na versão de produção.')
        : _editProfile,
    ),
  );

  Future<void> _editProfile() async {
    final result = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Editar dados de demonstração'),
        content: SingleChildScrollView(child: Column(mainAxisSize: MainAxisSize.min, children: [
          TextField(controller: _nameController, decoration: const InputDecoration(labelText: 'Nome do motorista')),
          const SizedBox(height: 10),
          TextField(controller: _carController, decoration: const InputDecoration(labelText: 'Marca/modelo da viatura')),
          const SizedBox(height: 10),
          TextField(controller: _plateController, decoration: const InputDecoration(labelText: 'Matrícula')),
          const SizedBox(height: 10),
          TextField(controller: _phoneController, keyboardType: TextInputType.phone, decoration: const InputDecoration(labelText: 'Telefone (opcional)')),
        ])),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Cancelar')),
          FilledButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('Guardar')),
        ],
      ),
    );
    if (result == true) setState(() {});
  }
}

class _TripRecord {
  final String destination;
  final int price;
  final DateTime date;
  const _TripRecord({required this.destination, required this.price, required this.date});
}
