# VEM Cliente — protótipo Flutter

Aplicação inicial para o lado do cliente do VEM. Interface e fluxos demonstrativos; ainda não está ligada a um backend, a motoristas reais, GPS ou mapas comerciais.

## Requisitos
- Flutter SDK instalado
- Android Studio ou VS Code com extensões Flutter/Dart
- Android SDK para executar num telemóvel/emulador

## Executar
1. Extrai o ZIP.
2. Abre a pasta `vem_cliente` no Android Studio ou VS Code.
3. No terminal, executa:
   ```bash
   flutter pub get
   flutter run
   ```

Para criar APK de teste:
```bash
flutter build apk --debug
```
O APK costuma ficar em `build/app/outputs/flutter-apk/app-debug.apk`.

## O que já está no protótipo
- Página inicial com mapa ilustrativo desenhado localmente (não é um mapa real).
- Campos de partida e destino.
- Escolha demonstrativa do tipo de viagem e pagamento.
- Estimativa com uma distância fixa de demonstração de 5 km.
- Fluxo simulado de procura e correspondência de motorista.
- Separadores de viagens e perfil.

## Antes de produção
- Definir tarifas oficiais e regras de cálculo.
- Integrar mapa/rotas e permissões de localização.
- Criar backend seguro com autenticação, pedidos e estados da viagem.
- Ligar as apps Cliente, Motorista e Operador em tempo real.
- Implementar notificações, suporte, pagamentos e avaliações.
- Configurar privacidade, segurança, testes e publicação.

A tarifa usada no exemplo é apenas demonstrativa: 300 Kz até 2,5 km e 120 Kz por km adicional, aplicada a uma distância simulada de 5 km. Confirma as regras finais antes de usar em viagens reais.
