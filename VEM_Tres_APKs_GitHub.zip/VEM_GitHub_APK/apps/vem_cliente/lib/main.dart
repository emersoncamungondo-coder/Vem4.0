import 'package:flutter/material.dart';

void main() => runApp(const VemClienteApp());

const vemGreen = Color(0xFF087F5B);
const vemDark = Color(0xFF10231D);
const vemMuted = Color(0xFF718078);
const vemBg = Color(0xFFF5F7F6);

class VemClienteApp extends StatelessWidget {
  const VemClienteApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'VEM Cliente',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        useMaterial3: true,
        scaffoldBackgroundColor: vemBg,
        colorScheme: ColorScheme.fromSeed(seedColor: vemGreen),
        fontFamily: 'Roboto',
        inputDecorationTheme: InputDecorationTheme(
          filled: true,
          fillColor: Colors.white,
          contentPadding: const EdgeInsets.symmetric(horizontal: 14, vertical: 15),
          border: OutlineInputBorder(
            borderRadius: BorderRadius.circular(14),
            borderSide: BorderSide.none,
          ),
        ),
      ),
      home: const VemHome(),
    );
  }
}

class VemHome extends StatefulWidget {
  const VemHome({super.key});

  @override
  State<VemHome> createState() => _VemHomeState();
}

class _VemHomeState extends State<VemHome> {
  int _tab = 0;
  final _pickup = TextEditingController(text: 'Localização actual');
  final _destination = TextEditingController();
  String _rideState = 'idle';
  String _payment = 'Dinheiro';
  String _rideType = 'VEM Económico';
  bool _showEstimate = false;

  @override
  void dispose() {
    _pickup.dispose();
    _destination.dispose();
    super.dispose();
  }

  int get _estimate {
    // Tarifa demonstrativa: 300 Kz nos primeiros 2,5 km + 120 Kz/km adicional.
    // A distância abaixo é simulada; substituir pelo cálculo real de rotas.
    const simulatedKm = 5.0;
    if (simulatedKm <= 2.5) return 300;
    return (300 + ((simulatedKm - 2.5) * 120)).round();
  }

  void _requestRide() {
    if (_destination.text.trim().isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Indica primeiro o teu destino.')),
      );
      return;
    }
    setState(() {
      _rideState = 'searching';
      _showEstimate = true;
    });
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (ctx) => _RideSearchingSheet(
        destination: _destination.text.trim(),
        estimate: _estimate,
        payment: _payment,
        onCancel: () {
          Navigator.pop(ctx);
          setState(() => _rideState = 'idle');
        },
        onDemoMatch: () {
          Navigator.pop(ctx);
          setState(() => _rideState = 'matched');
        },
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final pages = [
      _homePage(),
      _historyPage(),
      _profilePage(),
    ];
    return Scaffold(
      body: SafeArea(child: IndexedStack(index: _tab, children: pages)),
      bottomNavigationBar: NavigationBar(
        selectedIndex: _tab,
        onDestinationSelected: (i) => setState(() => _tab = i),
        backgroundColor: Colors.white,
        indicatorColor: vemGreen.withOpacity(.12),
        destinations: const [
          NavigationDestination(icon: Icon(Icons.map_outlined), selectedIcon: Icon(Icons.map), label: 'Início'),
          NavigationDestination(icon: Icon(Icons.receipt_long_outlined), selectedIcon: Icon(Icons.receipt_long), label: 'Viagens'),
          NavigationDestination(icon: Icon(Icons.person_outline), selectedIcon: Icon(Icons.person), label: 'Perfil'),
        ],
      ),
    );
  }

  Widget _homePage() {
    return Column(
      children: [
        Padding(
          padding: const EdgeInsets.fromLTRB(20, 14, 20, 12),
          child: Row(
            children: [
              Container(
                width: 46, height: 46,
                decoration: BoxDecoration(color: vemGreen, borderRadius: BorderRadius.circular(15)),
                child: const Icon(Icons.navigation_rounded, color: Colors.white, size: 26),
              ),
              const SizedBox(width: 12),
              const Expanded(child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text('VEM', style: TextStyle(fontSize: 23, fontWeight: FontWeight.w900, letterSpacing: 1.4, color: vemDark)),
                  Text('Vamos juntos.', style: TextStyle(color: vemMuted, fontSize: 12)),
                ],
              )),
              IconButton(
                onPressed: () => ScaffoldMessenger.of(context).showSnackBar(
                  const SnackBar(content: Text('As notificações serão ligadas na versão com servidor.')),
                ),
                icon: const Icon(Icons.notifications_none_rounded),
              ),
            ],
          ),
        ),
        Expanded(
          child: Stack(
            children: [
              const Positioned.fill(child: _DemoMap()),
              Positioned(
                top: 16, right: 16,
                child: FloatingActionButton.small(
                  heroTag: 'my_location',
                  backgroundColor: Colors.white,
                  foregroundColor: vemDark,
                  onPressed: () => ScaffoldMessenger.of(context).showSnackBar(
                    const SnackBar(content: Text('A localização real será activada na integração com GPS.')),
                  ),
                  child: const Icon(Icons.my_location),
                ),
              ),
              if (_rideState == 'matched')
                Positioned(
                  top: 16, left: 16, right: 76,
                  child: Card(
                    color: Colors.white,
                    child: const Padding(
                      padding: EdgeInsets.all(12),
                      child: Row(children: [
                        Icon(Icons.check_circle, color: vemGreen),
                        SizedBox(width: 8),
                        Expanded(child: Text('Motorista encontrado (modo demonstração)', style: TextStyle(fontWeight: FontWeight.w600))),
                      ]),
                    ),
                  ),
                ),
              Align(
                alignment: Alignment.bottomCenter,
                child: Container(
                  width: double.infinity,
                  constraints: const BoxConstraints(maxHeight: 465),
                  decoration: const BoxDecoration(
                    color: vemBg,
                    borderRadius: BorderRadius.vertical(top: Radius.circular(28)),
                  ),
                  child: SingleChildScrollView(
                    padding: const EdgeInsets.fromLTRB(20, 18, 20, 20),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Center(child: Container(width: 42, height: 4, decoration: BoxDecoration(color: Colors.black12, borderRadius: BorderRadius.circular(10)))),
                        const SizedBox(height: 16),
                        const Text('Para onde vamos?', style: TextStyle(fontSize: 22, fontWeight: FontWeight.w800, color: vemDark)),
                        const SizedBox(height: 5),
                        const Text('Escolhe a partida e o teu destino.', style: TextStyle(color: vemMuted)),
                        const SizedBox(height: 16),
                        Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
                          const Padding(padding: EdgeInsets.only(top: 15), child: Icon(Icons.my_location, size: 19, color: vemGreen)),
                          const SizedBox(width: 10),
                          Expanded(child: TextField(controller: _pickup, decoration: const InputDecoration(labelText: 'Local de partida'))),
                        ]),
                        Padding(
                          padding: const EdgeInsets.only(left: 9),
                          child: Container(width: 1, height: 14, color: Colors.black12),
                        ),
                        Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
                          const Padding(padding: EdgeInsets.only(top: 15), child: Icon(Icons.location_on, size: 20, color: Color(0xFFE45B55))),
                          const SizedBox(width: 10),
                          Expanded(child: TextField(
                            controller: _destination,
                            textInputAction: TextInputAction.done,
                            decoration: const InputDecoration(labelText: 'Destino', hintText: 'Ex.: Talatona, Luanda'),
                            onChanged: (_) => setState(() => _showEstimate = false),
                          )),
                        ]),
                        const SizedBox(height: 14),
                        Row(children: [
                          Expanded(child: _choiceTile(
                            icon: Icons.directions_car_filled_outlined,
                            title: _rideType,
                            subtitle: 'Confortável',
                            onTap: _chooseRideType,
                          )),
                          const SizedBox(width: 10),
                          Expanded(child: _choiceTile(
                            icon: Icons.payments_outlined,
                            title: _payment,
                            subtitle: 'Pagamento',
                            onTap: _choosePayment,
                          )),
                        ]),
                        if (_showEstimate) ...[
                          const SizedBox(height: 12),
                          Container(
                            width: double.infinity,
                            padding: const EdgeInsets.all(13),
                            decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(16)),
                            child: Row(children: [
                              const Icon(Icons.receipt_outlined, color: vemGreen),
                              const SizedBox(width: 10),
                              const Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                                Text('Preço estimado', style: TextStyle(color: vemMuted, fontSize: 12)),
                                Text('Distância simulada: 5 km', style: TextStyle(fontSize: 12)),
                              ])),
                              Text('${_estimate.toString()} Kz', style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w800)),
                            ]),
                          ),
                        ],
                        const SizedBox(height: 14),
                        SizedBox(
                          width: double.infinity, height: 54,
                          child: FilledButton.icon(
                            onPressed: _requestRide,
                            icon: const Icon(Icons.local_taxi_rounded),
                            label: Text(_rideState == 'matched' ? 'Pedir outra viagem' : 'Ver preço e pedir viagem'),
                            style: FilledButton.styleFrom(
                              backgroundColor: vemGreen, foregroundColor: Colors.white,
                              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
                              textStyle: const TextStyle(fontSize: 15, fontWeight: FontWeight.w700),
                            ),
                          ),
                        ),
                        const SizedBox(height: 4),
                        const Center(child: Text('Versão de demonstração • sem motorista real ligado', style: TextStyle(fontSize: 10, color: vemMuted))),
                      ],
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
      ],
    );
  }

  Widget _choiceTile({required IconData icon, required String title, required String subtitle, required VoidCallback onTap}) {
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(15),
      child: Container(
        padding: const EdgeInsets.all(12),
        decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(15)),
        child: Row(children: [
          Icon(icon, color: vemGreen, size: 22),
          const SizedBox(width: 8),
          Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text(title, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(fontSize: 12, fontWeight: FontWeight.w700)),
            Text(subtitle, style: const TextStyle(fontSize: 10, color: vemMuted)),
          ])),
          const Icon(Icons.keyboard_arrow_down, size: 17),
        ]),
      ),
    );
  }

  void _choosePayment() async {
    final choice = await showModalBottomSheet<String>(
      context: context,
      builder: (ctx) => _OptionSheet(
        title: 'Forma de pagamento',
        options: const ['Dinheiro', 'Multicaixa Express', 'Pagamento ao motorista'],
        selected: _payment,
      ),
    );
    if (choice != null) setState(() => _payment = choice);
  }

  void _chooseRideType() async {
    final choice = await showModalBottomSheet<String>(
      context: context,
      builder: (ctx) => _OptionSheet(
        title: 'Tipo de viagem',
        options: const ['VEM Económico', 'VEM Conforto', 'VEM XL'],
        selected: _rideType,
      ),
    );
    if (choice != null) setState(() => _rideType = choice);
  }

  Widget _historyPage() {
    return Padding(
      padding: const EdgeInsets.all(22),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        const SizedBox(height: 18),
        const Text('As minhas viagens', style: TextStyle(fontSize: 27, fontWeight: FontWeight.w800, color: vemDark)),
        const SizedBox(height: 8),
        const Text('As viagens concluídas aparecerão aqui.', style: TextStyle(color: vemMuted)),
        const SizedBox(height: 24),
        Container(
          width: double.infinity,
          padding: const EdgeInsets.all(28),
          decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(22)),
          child: const Column(children: [
            Icon(Icons.route_outlined, size: 52, color: vemGreen),
            SizedBox(height: 12),
            Text('Ainda não tens viagens', style: TextStyle(fontSize: 17, fontWeight: FontWeight.w700)),
            SizedBox(height: 6),
            Text('Quando fizeres a tua primeira viagem, os detalhes serão mostrados aqui.', textAlign: TextAlign.center, style: TextStyle(color: vemMuted)),
          ]),
        ),
      ]),
    );
  }

  Widget _profilePage() {
    return ListView(padding: const EdgeInsets.all(22), children: [
      const SizedBox(height: 18),
      const Text('O meu perfil', style: TextStyle(fontSize: 27, fontWeight: FontWeight.w800, color: vemDark)),
      const SizedBox(height: 20),
      Container(
        padding: const EdgeInsets.all(18),
        decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(20)),
        child: const Row(children: [
          CircleAvatar(radius: 28, backgroundColor: Color(0xFFE1F2EA), child: Icon(Icons.person, color: vemGreen, size: 30)),
          SizedBox(width: 14),
          Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text('Cliente VEM', style: TextStyle(fontSize: 17, fontWeight: FontWeight.w800)),
            Text('Perfil de demonstração', style: TextStyle(color: vemMuted)),
          ]),
        ]),
      ),
      const SizedBox(height: 16),
      _profileItem(Icons.person_outline, 'Dados pessoais', 'Nome, telefone e e-mail'),
      _profileItem(Icons.payment_outlined, 'Pagamentos', 'Gerir formas de pagamento'),
      _profileItem(Icons.support_agent_outlined, 'Ajuda e suporte', 'Precisas de ajuda?'),
      _profileItem(Icons.policy_outlined, 'Privacidade e termos', 'Informações da aplicação'),
      const SizedBox(height: 18),
      const Text('VEM Cliente • Protótipo 1.0', textAlign: TextAlign.center, style: TextStyle(color: vemMuted, fontSize: 12)),
    ]);
  }

  Widget _profileItem(IconData icon, String title, String subtitle) {
    return Card(
      elevation: 0,
      color: Colors.white,
      child: ListTile(
        leading: Icon(icon, color: vemGreen),
        title: Text(title, style: const TextStyle(fontWeight: FontWeight.w700)),
        subtitle: Text(subtitle),
        trailing: const Icon(Icons.chevron_right),
        onTap: () => ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('$title estará disponível na versão ligada ao servidor.'))),
      ),
    );
  }
}

class _DemoMap extends StatelessWidget {
  const _DemoMap();

  @override
  Widget build(BuildContext context) {
    return CustomPaint(
      painter: _MapPainter(),
      child: Stack(children: const [
        Positioned(left: 30, top: 75, child: _MapLabel('MAIANGA')),
        Positioned(right: 34, top: 132, child: _MapLabel('MUTAMBA')),
        Positioned(left: 65, top: 210, child: _MapLabel('LUANDA')),
        Positioned(right: 62, bottom: 255, child: _MapLabel('MARGINAL')),
        Positioned(left: 118, top: 135, child: _MapPin(color: vemGreen, icon: Icons.my_location)),
        Positioned(right: 105, top: 220, child: _MapPin(color: Color(0xFFE45B55), icon: Icons.location_on)),
      ]),
    );
  }
}

class _MapLabel extends StatelessWidget {
  final String text;
  const _MapLabel(this.text);
  @override
  Widget build(BuildContext context) => Text(text, style: const TextStyle(fontSize: 9, letterSpacing: 1.2, color: Color(0xFF83958C), fontWeight: FontWeight.w700));
}

class _MapPin extends StatelessWidget {
  final Color color;
  final IconData icon;
  const _MapPin({required this.color, required this.icon});
  @override
  Widget build(BuildContext context) => Container(
    width: 38, height: 38,
    decoration: BoxDecoration(color: color, shape: BoxShape.circle, border: Border.all(color: Colors.white, width: 3), boxShadow: const [BoxShadow(color: Colors.black12, blurRadius: 8, offset: Offset(0, 3))]),
    child: Icon(icon, color: Colors.white, size: 19),
  );
}

class _MapPainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    final bg = Paint()..color = const Color(0xFFEAF0EC);
    canvas.drawRect(Offset.zero & size, bg);
    final park = Paint()..color = const Color(0xFFD6E8D9);
    canvas.drawRRect(RRect.fromRectAndRadius(Rect.fromLTWH(size.width * .62, 20, 130, 105), const Radius.circular(22)), park);
    canvas.drawRRect(RRect.fromRectAndRadius(Rect.fromLTWH(12, size.height * .36, 80, 115), const Radius.circular(25)), park);
    final road = Paint()..color = Colors.white..strokeWidth = 13..style = PaintingStyle.stroke..strokeCap = StrokeCap.round;
    final road2 = Paint()..color = const Color(0xFFD7E0DA)..strokeWidth = 2..style = PaintingStyle.stroke;
    final paths = <Path>[
      Path()..moveTo(-20, size.height * .22)..cubicTo(size.width * .25, size.height * .25, size.width * .3, size.height * .55, size.width + 20, size.height * .32),
      Path()..moveTo(size.width * .18, -20)..cubicTo(size.width * .28, size.height * .25, size.width * .62, size.height * .42, size.width * .55, size.height + 20),
      Path()..moveTo(-10, size.height * .65)..cubicTo(size.width * .35, size.height * .52, size.width * .55, size.height * .78, size.width + 10, size.height * .66),
      Path()..moveTo(size.width * .82, -10)..cubicTo(size.width * .68, size.height * .25, size.width * .8, size.height * .5, size.width * .72, size.height + 10),
    ];
    for (final p in paths) {
      canvas.drawPath(p, road);
      canvas.drawPath(p, road2);
    }
    final route = Paint()..color = vemGreen..strokeWidth = 4..style = PaintingStyle.stroke..strokeCap = StrokeCap.round;
    final routePath = Path()
      ..moveTo(size.width * .34, size.height * .31)
      ..cubicTo(size.width * .42, size.height * .39, size.width * .42, size.height * .47, size.width * .58, size.height * .55);
    canvas.drawPath(routePath, route);
  }
  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}

class _OptionSheet extends StatelessWidget {
  final String title;
  final List<String> options;
  final String selected;
  const _OptionSheet({required this.title, required this.options, required this.selected});

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Padding(
        padding: const EdgeInsets.fromLTRB(20, 22, 20, 28),
        child: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text(title, style: const TextStyle(fontSize: 21, fontWeight: FontWeight.w800)),
          const SizedBox(height: 12),
          ...options.map((option) => ListTile(
            contentPadding: EdgeInsets.zero,
            title: Text(option),
            trailing: option == selected ? const Icon(Icons.check_circle, color: vemGreen) : const Icon(Icons.circle_outlined, color: Colors.black26),
            onTap: () => Navigator.pop(context, option),
          )),
        ]),
      ),
    );
  }
}

class _RideSearchingSheet extends StatelessWidget {
  final String destination;
  final int estimate;
  final String payment;
  final VoidCallback onCancel;
  final VoidCallback onDemoMatch;
  const _RideSearchingSheet({
    required this.destination,
    required this.estimate,
    required this.payment,
    required this.onCancel,
    required this.onDemoMatch,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.fromLTRB(22, 24, 22, 28),
      decoration: const BoxDecoration(color: Colors.white, borderRadius: BorderRadius.vertical(top: Radius.circular(28))),
      child: SafeArea(
        child: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.start, children: [
          Center(child: Container(width: 42, height: 4, decoration: BoxDecoration(color: Colors.black12, borderRadius: BorderRadius.circular(8)))),
          const SizedBox(height: 20),
          const Center(child: Icon(Icons.local_taxi_rounded, size: 44, color: vemGreen)),
          const SizedBox(height: 12),
          const Center(child: Text('A procurar motorista', style: TextStyle(fontSize: 22, fontWeight: FontWeight.w800))),
          const SizedBox(height: 7),
          const Center(child: Text('Esta é uma simulação. Ainda não há motoristas ligados ao sistema.', textAlign: TextAlign.center, style: TextStyle(color: vemMuted))),
          const SizedBox(height: 22),
          _detailRow(Icons.location_on_outlined, 'Destino', destination),
          _detailRow(Icons.payments_outlined, 'Preço estimado', '$estimate Kz'),
          _detailRow(Icons.account_balance_wallet_outlined, 'Pagamento', payment),
          const SizedBox(height: 18),
          SizedBox(width: double.infinity, child: FilledButton(
            onPressed: onDemoMatch,
            style: FilledButton.styleFrom(backgroundColor: vemGreen, foregroundColor: Colors.white, padding: const EdgeInsets.all(15)),
            child: const Text('Simular motorista encontrado'),
          )),
          TextButton(onPressed: onCancel, child: const Center(child: Text('Cancelar pedido', style: TextStyle(color: Colors.redAccent)))),
        ]),
      ),
    );
  }

  Widget _detailRow(IconData icon, String label, String value) => Padding(
    padding: const EdgeInsets.symmetric(vertical: 7),
    child: Row(children: [
      Icon(icon, color: vemGreen, size: 21),
      const SizedBox(width: 10),
      Expanded(child: Text(label, style: const TextStyle(color: vemMuted))),
      Flexible(child: Text(value, textAlign: TextAlign.end, style: const TextStyle(fontWeight: FontWeight.w700))),
    ]),
  );
}
